from dencoder import encrypt
from dencoder import decrypt
from dencoder import encryptfromfile
from dencoder import decryptfromfile